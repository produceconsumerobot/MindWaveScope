# Utilities

These are little tools I made for myself while working on Arduinoscope.  You will need [node.js](http://nodejs.org/) to use them. You or may not find them useful. I put dependencies for everything in package.json, so you can get everything with `npm install`

## scope

This is a command-line oscilloscope, using Firmata on your Arduino (File -> Open -> Examples > Library-Firmata > StandardFirmata, in latest Arduino IDE.)

